Predictions "\results\datafiles\my_targets.data"
Results \results\plots|
Model "C:\Users\azatv\VSCode\VSCProjects\Second Python\Assign7\results\best_model.pt"